<?php

echo 5 + 7;
echo '<br>';
echo 10 - 5;
echo '<br>';
echo 2 * 2;
echo '<br>';
echo 10 / 5;
echo '<br>';
echo 10 % 2;
echo '<br>';
echo 2 ** 10;
echo '<br>';

echo (2 + 3) * 5;
echo '<br>';

$a = 5; // $a++ => $a = $a + 1;
echo $a++;
echo '<br>';
echo ++$a;
echo '<br>';

$b = 7;
echo $b--;
echo '<br>';
echo --$b;
echo '<br>';

$x = 10;
$y = 5;
echo $x += $y;
echo '<br>'; // $x = $x + $y;
echo $x -= $y;
echo '<br>';
echo $x *= $y;
echo '<br>';
echo $x /= $y;
echo '<br>';
echo $x .= $y;
echo '<br>'; // $x = $x . $y;
