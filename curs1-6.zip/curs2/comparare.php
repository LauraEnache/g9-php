<?php

$a = 5;
$b = '5';

var_dump($a == $b);
echo '<br>';
var_dump($a === $b);
echo '<br>';
var_dump($a != $b);
echo '<br>';
var_dump($a <> $b); // != equals <>
echo '<br>';
var_dump($a !== $b);
echo '<br>';

$b = 8;
var_dump($a > $b);
echo '<br>';
var_dump($a < $b);
echo '<br>';
$b = 5;
var_dump($a >= $b);
echo '<br>';
var_dump($a <= $b);
echo '<br>';
$b = 1;
var_dump($a <=> $b);
echo '<br>';

$m = true;
$p = !$m;
var_dump($p);
echo '<br>';

echo '<hr/>';

var_dump(false && false);
echo '<br>';
var_dump(false && true);
echo '<br>';
var_dump(true && true);
echo '<br>';
var_dump(true && false);
echo '<br>';

var_dump(false || false);
echo '<br>';
var_dump(false || true);
echo '<br>';
var_dump(true || true);
echo '<br>';
var_dump(true || false);
echo '<br>';

var_dump(5 < 3 xor 5 > 2);
echo '<br>';

$q = 1; // 1 -> true
$w = 0; // 0 -> false
var_dump($q || $w);
echo '<br>';

echo '<hr>';

$t = (2 > 3) ? 'true' : 'false';
var_dump($t);
echo '<br>';

echo '<hr>';

$g = null;
$j = 3;

$x = $g ?? 10;
$y = $j ?? 10;

var_dump($x, $y);

// proof git branches
