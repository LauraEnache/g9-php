<?php

include_once 'functions.php';

function query()
{
    connect();

    echo 'query our database';
}
