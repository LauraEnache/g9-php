<?php

// include_once 'config.php';
require_once 'functions.php';
require_once 'helpers.php';

connect();

query();
