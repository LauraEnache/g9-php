<?php

define('DB_HOST', 'localhost');
