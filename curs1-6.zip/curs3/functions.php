<?php

//include('config.php');
include_once 'config/config.php';

function connect()
{
    echo DB_HOST;
}

// $firstName -> camel case
// $first_name -> snake case
// for class names -> CarBrand -> studdly case
class CarBrand
{
}
